const mongoose = require("mongoose");

const Userschema = mongoose.Schema(
    {
        bookname: {
            type: String,
            required: [true, "Please enter Book name"]
        },
        authorname: {
            type: String,
            required: true,
            default: 0
        },
        ratings: {
            type: Number,
            required: true
        }
    },
    {
        timestamps: true
    }
);
const user = mongoose.model("users",Userschema);

module.exports = user;