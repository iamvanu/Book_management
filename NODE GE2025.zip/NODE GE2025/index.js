const express=require("express");
const app=express();
const userroute=require("./route/router");
const mangoose=require("mongoose");
const dotenv=require("dotenv");
const { default: mongoose } = require("mongoose");

dotenv.config();

//middleware to convert the join
app.use(express.json());

//API route
app.use("/api/users", userroute);

//Test route
app.get("/",(req,res) => {
    res.send("this is the response from a node API which is updated");
});

//start server
app.listen(3000, () => {
    console.log("server is runnig on port 3000");
});

//mongodb connection
mongoose
.connect(process.env.MONGO_CONNECTION_STRING)
.then(() => {
    console.log("connected to mongodb:");
})
.catch((err) => {
    console.error("connection Failed!" ,err);
});



