const Book = require('../models/models'); // Make sure the filename is correct

// Retrieve all tasks
const getAllBook = async (req, res) => {
  try {
    const tasks = await Book.find(); // Capital T
    res.status(200).json(tasks);
  } catch (error) {
    res.status(500).json({ message: error.message });
  }
};

// Retrieve task by ID
const getBookById = async (req, res) => {
  try {
    const { id } = req.params;
    const singleTask = await Book.findById(id); // Capital T
    if (!singleTask) {
      return res.status(404).json({ message: "Task not found" });
    }
    res.status(200).json(singleTask);
  } catch (error) {
    res.status(500).json({ message: error.message });
  }
};

// Create a new task
const createBook = async (req, res) => {
  try {
    const newTask = await Book.create(req.body); // Capital T
    res.status(201).json(newTask);
  } catch (error) {
    res.status(500).json({ message: error.message });
  }
}
const user = require("../models/models");

//update a user 
const updateBook = async (req,res) => {
    try {
        const { id } = req.params;
        const user = await Book.findByIdAndUpdate(id, req.body, { new: true });

        if (!user) {
            return res.status(404).json({ message: "user not found" });
         }

         res.status(200).json(user);
    } catch (error) {
         res.status(500).json({message: error/message });
        }
    };      
    
    //delete a user 
    const deleteBook = async (req,res) => {
        try {
            const { id } = req.params;
            const user = await Book.findByIdAndDelete(id);

            if (!user) {
                return res.status(400).json({ message: "user not found "});
            }

            res.status(200).json({ message: "user delete successfully" })
        } catch {error} {
            res.status(500).json({ message: error.message });
        }
    };

    module.exports = {
       getAllBook,
       getBookById,
       createBook,
       updateBook,
       deleteBook
    };

       